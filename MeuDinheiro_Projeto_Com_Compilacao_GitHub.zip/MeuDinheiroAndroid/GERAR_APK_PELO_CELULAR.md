# Meu Dinheiro — gerar APK pelo celular usando GitHub

## Antes de começar
- Tenha uma conta gratuita no GitHub.
- Baixe e extraia este ZIP no celular usando o app Arquivos/Meus Arquivos.
- O projeto deve ser enviado para um repositório GitHub.

## Passo a passo pelo celular
1. Abra https://github.com e crie uma conta ou entre nela.
2. Toque no sinal `+` e escolha `New repository`.
3. Nome: `meu-dinheiro-android`. Marque `Public` (necessário para usar GitHub Actions grátis sem configurar cobrança) e toque em `Create repository`.
4. Na página do repositório, escolha `Add file` > `Upload files`.
5. No gerenciador de arquivos, abra a pasta extraída `MeuDinheiroAndroid` e selecione o CONTEÚDO dela (incluindo `app`, `gradle.properties`, `build.gradle.kts`, `settings.gradle.kts` e a pasta oculta `.github`). Envie os arquivos para a raiz do repositório. Se o seletor não permitir selecionar pastas/conteúdo em lote, use o navegador em modo computador ou o app GitHub Mobile/um gerenciador de arquivos que permita selecionar múltiplos arquivos.
6. Faça o commit usando o botão `Commit changes`.
7. Abra a aba `Actions` do repositório. Se aparecer uma confirmação para habilitar workflows, confirme.
8. Se o workflow não iniciar sozinho, entre em `Gerar APK Meu Dinheiro`, toque em `Run workflow` e confirme.
9. Aguarde a execução terminar com marca verde. Se aparecer X vermelho, abra a execução e consulte o primeiro erro em vermelho.
10. Na página da execução concluída, vá até `Artifacts` e toque em `MeuDinheiro-debug-apk` para baixar o ZIP com o APK dentro.
11. Extraia esse ZIP no celular e toque em `app-debug.apk` para instalar. Autorize a instalação pelo navegador/gerenciador de arquivos quando o Android solicitar.

## Observações importantes
- Este fluxo gera um APK debug para teste, não uma versão assinada para publicação na Play Store.
- O projeto ainda é uma versão inicial: não possui conexão bancária Open Finance real nem autenticação completa por senha/biometria.
- O workflow depende de o projeto compilar. Se falhar, compartilhe uma captura da mensagem de erro para corrigirmos.
