# Meu Dinheiro — Android (etapa 2)

Projeto inicial em Kotlin + Jetpack Compose com navegação e persistência Room.

## Telas implementadas
- Início: saldo calculado, totais e últimos lançamentos
- Movimentações: lista e exclusão de lançamentos
- Novo lançamento: cadastro de entrada ou despesa persistido no Room
- Contas: cadastro de contas/carteiras
- Cartões: cadastro de cartões, limite e dias de fechamento/vencimento
- Relatórios: totais de entradas, despesas e resultado

## Tecnologias
- Kotlin
- Jetpack Compose + Material 3
- Navigation Compose
- Room / SQLite
- Kotlin Coroutines e Flow

## Abrir e executar
1. Extraia o ZIP.
2. Abra a pasta `MeuDinheiroAndroid` no Android Studio.
3. Use JDK 17 e instale Android SDK 35.
4. Aguarde a sincronização Gradle e execute em um aparelho/emulador.

## Observações importantes
- O banco Room local é inicializado automaticamente e os lançamentos/contas/cartões cadastrados são persistidos no aparelho.
- A tela de relatórios mostra totais gerais, ainda sem filtros mensais e gráficos.
- Os cartões são cadastrados localmente; ainda não existe importação de fatura nem cálculo de parcelas.
- O módulo Open Finance permanece como contrato/abstração. Não existe conexão bancária ativa, backend, credenciais ou consentimento real nesta versão.
- O login por senha e a biometria ainda não estão conectados ao fluxo principal da interface. O arquivo de exemplo biométrico da etapa anterior é apenas uma base técnica.
- Antes de uso real, implementar autenticação segura, backup, migrações Room, testes, revisão de segurança e integração Open Finance através de provedor/participante adequado.
