package br.com.meudinheiro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import br.com.meudinheiro.data.*
import br.com.meudinheiro.ui.theme.MeuDinheiroTheme
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.time.LocalDate
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = AppDatabase.getInstance(applicationContext).financeDao()
        setContent { MeuDinheiroTheme { MeuDinheiroApp(dao) } }
    }
}

private data class NavItem(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@Composable
private fun MeuDinheiroApp(dao: FinanceDao) {
    val nav = rememberNavController()
    val items = listOf(
        NavItem("inicio", "Início", Icons.Default.Home),
        NavItem("movimentos", "Movimentos", Icons.Default.SwapVert),
        NavItem("contas", "Contas", Icons.Default.AccountBalance),
        NavItem("cartoes", "Cartões", Icons.Default.CreditCard),
        NavItem("relatorios", "Relatórios", Icons.Default.BarChart)
    )
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                val current = nav.currentBackStackEntryAsState().value?.destination?.route
                items.forEach { item ->
                    NavigationBarItem(
                        selected = current == item.route,
                        onClick = {
                            nav.navigate(item.route) {
                                popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(item.icon, contentDescription = item.label) },
                        label = { Text(item.label) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(navController = nav, startDestination = "inicio", modifier = Modifier.padding(padding)) {
            composable("inicio") { HomeScreen(dao, onAdd = { nav.navigate("novo") }) }
            composable("movimentos") { TransactionsScreen(dao, onAdd = { nav.navigate("novo") }) }
            composable("contas") { AccountsScreen(dao) }
            composable("cartoes") { CardsScreen(dao) }
            composable("relatorios") { ReportsScreen(dao) }
            composable("novo") { NewTransactionScreen(dao, onDone = { nav.popBackStack() }, onCancel = { nav.popBackStack() }) }
        }
    }
}

@Composable
private fun HomeScreen(dao: FinanceDao, onAdd: () -> Unit) {
    val transactions by dao.observeTransactions().collectAsState(initial = emptyList())
    val accounts by dao.observeAccounts().collectAsState(initial = emptyList())
    val income = transactions.filter { it.type == TransactionType.INCOME }.sumOf { it.amountCents }
    val expenses = transactions.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amountCents }
    val fmt = remember { NumberFormat.getCurrencyInstance(Locale("pt", "BR")) }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Spacer(Modifier.height(8.dp))
            Text("MEU DINHEIRO", color = Mint, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            Text("Seu dinheiro. Seu controle.", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Green), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                    Text("SALDO DAS MOVIMENTAÇÕES", color = Color(0xFFD2E8DC))
                    Spacer(Modifier.height(4.dp))
                    Text(fmt.format((income - expenses) / 100.0), color = Color.White, style = MaterialTheme.typography.headlineLarge)
                    Spacer(Modifier.height(18.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("Entradas", color = Mint)
                            Text(fmt.format(income / 100.0), color = Color.White, fontWeight = FontWeight.SemiBold)
                        }
                        Column {
                            Text("Despesas", color = Color(0xFFFFC2C2))
                            Text(fmt.format(expenses / 100.0), color = Color.White, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Visão geral", style = MaterialTheme.typography.titleLarge)
                Text("${accounts.size} conta(s)", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SummaryTile("Entradas", fmt.format(income / 100.0), Icons.Default.TrendingUp, Modifier.weight(1f))
                SummaryTile("Despesas", fmt.format(expenses / 100.0), Icons.Default.TrendingDown, Modifier.weight(1f))
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Últimos lançamentos", style = MaterialTheme.typography.titleMedium)
                TextButton(onClick = onAdd) { Icon(Icons.Default.Add, null); Text("Adicionar") }
            }
        }
        if (transactions.isEmpty()) {
            item { EmptyState("Ainda não há movimentações", "Toque em Adicionar para registrar sua primeira entrada ou despesa.") }
        } else {
            items(transactions.take(5), key = { it.id }) { tx -> TransactionRow(tx, onDelete = { /* exclusão na tela de movimentos */ }) }
        }
    }
}

@Composable
private fun SummaryTile(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(14.dp)) {
            Icon(icon, null, tint = Mint)
            Spacer(Modifier.height(8.dp))
            Text(title, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun TransactionsScreen(dao: FinanceDao, onAdd: () -> Unit) {
    val transactions by dao.observeTransactions().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Movimentações", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            FilledTonalButton(onClick = onAdd) { Icon(Icons.Default.Add, null); Text("Novo") }
        }
        Spacer(Modifier.height(12.dp))
        if (transactions.isEmpty()) EmptyState("Nenhum lançamento", "Cadastre entradas e despesas para acompanhar seu dinheiro.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(transactions, key = { it.id }) { tx ->
                TransactionRow(tx, onDelete = { scope.launch { dao.deleteTransaction(tx) } })
            }
        }
    }
}

@Composable
private fun TransactionRow(tx: Transaction, onDelete: () -> Unit) {
    val fmt = remember { NumberFormat.getCurrencyInstance(Locale("pt", "BR")) }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                Icon(if (tx.type == TransactionType.INCOME) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                    null, modifier = Modifier.padding(10.dp), tint = if (tx.type == TransactionType.INCOME) Mint else MaterialTheme.colorScheme.error)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(tx.description, fontWeight = FontWeight.SemiBold)
                Text("${tx.category} • ${tx.date}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text((if (tx.type == TransactionType.INCOME) "+ " else "− ") + fmt.format(tx.amountCents / 100.0),
                    color = if (tx.type == TransactionType.INCOME) Mint else MaterialTheme.colorScheme.error,
                    fontWeight = FontWeight.Bold)
                IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.DeleteOutline, "Excluir lançamento", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(17.dp))
                }
            }
        }
    }
}

@Composable
private fun NewTransactionScreen(dao: FinanceDao, onDone: () -> Unit, onCancel: () -> Unit) {
    val scope = rememberCoroutineScope()
    var description by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Outros") }
    var type by remember { mutableStateOf(TransactionType.EXPENSE) }
    var error by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Novo lançamento", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        OutlinedTextField(description, { description = it }, label = { Text("Descrição") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(amount, { amount = it }, label = { Text("Valor (R$)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(category, { category = it }, label = { Text("Categoria") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Row(verticalAlignment = Alignment.CenterVertically) {
            FilterChip(selected = type == TransactionType.EXPENSE, onClick = { type = TransactionType.EXPENSE }, label = { Text("Despesa") })
            Spacer(Modifier.width(8.dp))
            FilterChip(selected = type == TransactionType.INCOME, onClick = { type = TransactionType.INCOME }, label = { Text("Entrada") })
        }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Spacer(Modifier.weight(1f))
        Button(onClick = {
            val cents = amount.trim().replace(".", "").replace(",", ".").toBigDecimalOrNull()
                ?.multiply(100.toBigDecimal())?.toLong()
            if (description.isBlank() || cents == null || cents <= 0) {
                error = "Informe uma descrição e um valor válido maior que zero."
            } else {
                scope.launch {
                    dao.saveTransaction(Transaction(
                        description = description.trim(), category = category.trim().ifBlank { "Outros" },
                        amountCents = cents, type = type, date = LocalDate.now().toString()
                    ))
                    onDone()
                }
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("Salvar lançamento") }
        OutlinedButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) { Text("Cancelar") }
    }
}

@Composable
private fun AccountsScreen(dao: FinanceDao) {
    val accounts by dao.observeAccounts().collectAsState(initial = emptyList())
    var show by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Minhas contas", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            FilledTonalButton(onClick = { show = true }) { Icon(Icons.Default.Add, null); Text("Adicionar") }
        }
        Spacer(Modifier.height(12.dp))
        if (accounts.isEmpty()) EmptyState("Nenhuma conta cadastrada", "Adicione sua carteira, conta corrente ou poupança.")
        else LazyColumn {
            items(accounts, key = { it.id }) { account ->
                ListItem(
                    headlineContent = { Text(account.name) },
                    supportingContent = { Text("${account.accountType}${account.institution?.let { " • $it" } ?: ""}") },
                    leadingContent = { Icon(Icons.Default.AccountBalanceWallet, null, tint = Mint) }
                )
                HorizontalDivider()
            }
        }
    }
    if (show) {
        var name by remember { mutableStateOf("") }
        var institution by remember { mutableStateOf("") }
        var kind by remember { mutableStateOf("Conta corrente") }
        AlertDialog(
            onDismissRequest = { show = false },
            title = { Text("Adicionar conta") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(name, { name = it }, label = { Text("Nome da conta") })
                    OutlinedTextField(institution, { institution = it }, label = { Text("Banco (opcional)") })
                    OutlinedTextField(kind, { kind = it }, label = { Text("Tipo: corrente, poupança, carteira...") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (name.isNotBlank()) scope.launch {
                        dao.saveAccount(Account(name = name.trim(), institution = institution.trim().ifBlank { null }, accountType = kind.trim()))
                        show = false
                    }
                }) { Text("Salvar") }
            },
            dismissButton = { TextButton(onClick = { show = false }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun CardsScreen(dao: FinanceDao) {
    val cards by dao.observeCards().collectAsState(initial = emptyList())
    var show by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val fmt = remember { NumberFormat.getCurrencyInstance(Locale("pt", "BR")) }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Cartões", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            FilledTonalButton(onClick = { show = true }) { Icon(Icons.Default.Add, null); Text("Adicionar") }
        }
        Spacer(Modifier.height(12.dp))
        if (cards.isEmpty()) EmptyState("Nenhum cartão cadastrado", "Cadastre seus cartões para acompanhar limites e datas de fechamento.")
        else LazyColumn {
            items(cards, key = { it.id }) { card ->
                Card(Modifier.fillMaxWidth().padding(bottom = 10.dp), colors = CardDefaults.cardColors(containerColor = Green)) {
                    Column(Modifier.padding(18.dp)) {
                        Text(card.name, color = Color.White, style = MaterialTheme.typography.titleLarge)
                        Text(card.brand ?: "Cartão", color = Mint)
                        Spacer(Modifier.height(14.dp))
                        Text("Limite: ${fmt.format(card.limitCents / 100.0)}", color = Color.White)
                        Text("Fecha dia ${card.closingDay} • Vence dia ${card.dueDay}", color = Color(0xFFD2E8DC))
                    }
                }
            }
        }
    }
    if (show) {
        var name by remember { mutableStateOf("") }
        var brand by remember { mutableStateOf("") }
        var limit by remember { mutableStateOf("") }
        var closing by remember { mutableStateOf("10") }
        var due by remember { mutableStateOf("17") }
        AlertDialog(
            onDismissRequest = { show = false },
            title = { Text("Cadastrar cartão") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(name, { name = it }, label = { Text("Nome (ex.: Cartão principal)") })
                    OutlinedTextField(brand, { brand = it }, label = { Text("Bandeira (opcional)") })
                    OutlinedTextField(limit, { limit = it }, label = { Text("Limite em R$") })
                    OutlinedTextField(closing, { closing = it }, label = { Text("Dia de fechamento") })
                    OutlinedTextField(due, { due = it }, label = { Text("Dia de vencimento") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val cents = limit.replace(".", "").replace(",", ".").toBigDecimalOrNull()
                        ?.multiply(100.toBigDecimal())?.toLong()
                    val c = closing.toIntOrNull()
                    val d = due.toIntOrNull()
                    if (name.isNotBlank() && cents != null && cents > 0 && c in 1..31 && d in 1..31) {
                        scope.launch {
                            dao.saveCard(CreditCard(name = name.trim(), brand = brand.trim().ifBlank { null },
                                limitCents = cents, closingDay = c!!, dueDay = d!!))
                            show = false
                        }
                    }
                }) { Text("Salvar") }
            },
            dismissButton = { TextButton(onClick = { show = false }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun ReportsScreen(dao: FinanceDao) {
    val transactions by dao.observeTransactions().collectAsState(initial = emptyList())
    val income = transactions.filter { it.type == TransactionType.INCOME }.sumOf { it.amountCents }
    val expenses = transactions.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amountCents }
    val fmt = remember { NumberFormat.getCurrencyInstance(Locale("pt", "BR")) }
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Relatórios", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        SummaryTile("Total de entradas", fmt.format(income / 100.0), Icons.Default.TrendingUp, Modifier.fillMaxWidth())
        SummaryTile("Total de despesas", fmt.format(expenses / 100.0), Icons.Default.TrendingDown, Modifier.fillMaxWidth())
        SummaryTile("Resultado", fmt.format((income - expenses) / 100.0), Icons.Default.AccountBalanceWallet, Modifier.fillMaxWidth())
        Text("Os totais consideram todos os lançamentos registrados. Filtros por mês e gráficos serão adicionados na próxima evolução.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun EmptyState(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 38.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.AccountBalanceWallet, null, tint = Mint, modifier = Modifier.size(42.dp))
        Spacer(Modifier.height(10.dp))
        Text(title, fontWeight = FontWeight.Bold)
        Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
    }
}

private val Green = Color(0xFF153D32)
private val Mint = Color(0xFFA7E5C3)
