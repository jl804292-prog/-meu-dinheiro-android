package br.com.meudinheiro.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Green = Color(0xFF153D32)
private val Mint = Color(0xFFA7E5C3)
private val Black = Color(0xFF080D0B)

@Composable
fun MeuDinheiroTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = Mint,
        onPrimary = Black,
        secondary = Green,
        background = Black,
        surface = Color(0xFF121B17),
        surfaceVariant = Color(0xFF1D2B24),
        onSurface = Color(0xFFF2F5F3),
        onBackground = Color(0xFFF2F5F3)
    )
    MaterialTheme(colorScheme = scheme, content = content)
}
