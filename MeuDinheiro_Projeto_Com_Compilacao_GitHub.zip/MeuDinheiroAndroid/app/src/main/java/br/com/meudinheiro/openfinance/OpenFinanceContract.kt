package br.com.meudinheiro.openfinance

/**
 * Contrato da integração. Implementar no BACKEND, nunca inserir segredo
 * de provedor, certificado ou client_secret dentro do APK.
 */
data class BankConnection(
    val id: String,
    val institutionName: String,
    val status: ConsentStatus,
    val consentExpiresAt: String?
)

enum class ConsentStatus { PENDING, ACTIVE, EXPIRED, REVOKED, ERROR }

data class OpenFinanceTransaction(
    val externalId: String,
    val description: String,
    val amountCents: Long,
    val currency: String,
    val bookingDate: String,
    val accountReference: String
)

interface OpenFinanceGateway {
    /** Backend cria uma sessão de consentimento e devolve URL de autorização. */
    suspend fun createConsentSession(): String

    /** Consultar conexões autorizadas e seu estado. */
    suspend fun listConnections(): List<BankConnection>

    /** Buscar dados financeiros normalizados do backend. */
    suspend fun getTransactions(connectionId: String): List<OpenFinanceTransaction>

    /** Solicitar revogação/cancelamento do consentimento. */
    suspend fun revokeConsent(connectionId: String)
}
