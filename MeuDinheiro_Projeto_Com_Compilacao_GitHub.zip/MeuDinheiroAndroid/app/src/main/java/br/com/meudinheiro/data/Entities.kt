package br.com.meudinheiro.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TransactionType { INCOME, EXPENSE, TRANSFER }

@Entity(tableName = "accounts")
data class Account(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val institution: String? = null,
    val accountType: String,
    val balanceCents: Long = 0,
    val currency: String = "BRL",
    val openFinanceConnectionId: String? = null
)

@Entity(tableName = "transactions")
data class Transaction(
    @PrimaryKey val id: Long = 0,
    val description: String,
    val category: String,
    val amountCents: Long,
    val type: TransactionType,
    val date: String,
    val accountId: Long? = null,
    val cardId: Long? = null,
    val installmentGroupId: String? = null,
    val isRecurring: Boolean = false,
    val notes: String? = null,
    val externalTransactionId: String? = null
)

@Entity(tableName = "cards")
data class CreditCard(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val brand: String? = null,
    val lastFourDigits: String? = null,
    val limitCents: Long,
    val closingDay: Int,
    val dueDay: Int,
    val accountId: Long? = null
)

@Entity(tableName = "invoices")
data class Invoice(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val cardId: Long,
    val referenceMonth: String,
    val totalCents: Long = 0,
    val status: String = "OPEN",
    val dueDate: String
)
