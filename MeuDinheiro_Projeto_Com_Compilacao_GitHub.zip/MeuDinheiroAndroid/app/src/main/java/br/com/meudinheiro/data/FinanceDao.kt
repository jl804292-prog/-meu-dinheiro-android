package br.com.meudinheiro.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface FinanceDao {
    @Query("SELECT * FROM accounts ORDER BY name")
    fun observeAccounts(): Flow<List<Account>>

    @Query("SELECT * FROM transactions ORDER BY date DESC, id DESC")
    fun observeTransactions(): Flow<List<Transaction>>

    @Query("SELECT * FROM cards ORDER BY name")
    fun observeCards(): Flow<List<CreditCard>>

    @Query("SELECT * FROM invoices WHERE cardId = :cardId ORDER BY dueDate DESC")
    fun observeInvoices(cardId: Long): Flow<List<Invoice>>

    @Query("SELECT * FROM invoices ORDER BY dueDate")
    fun observeAllInvoices(): Flow<List<Invoice>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveAccount(account: Account): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveTransaction(transaction: Transaction)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveCard(card: CreditCard): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveInvoice(invoice: Invoice)

    @Delete suspend fun deleteTransaction(transaction: Transaction)
    @Delete suspend fun deleteAccount(account: Account)
    @Delete suspend fun deleteCard(card: CreditCard)
}
